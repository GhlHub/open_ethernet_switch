#!/usr/bin/env python3
"""KR260 open-I/O clamshell prototype. Dimensions in mm; see README.md.

Run with Python + requirements.txt. STEP uses assembly coordinates; STL is
rotated (never mirrored) onto the print bed. No vendor CAD is redistributed.
"""
from pathlib import Path
import json

import cadquery as cq
import trimesh

OUT = Path(__file__).resolve().parent / "output"
W, D, H = 168.0, 160.0, 68.0
WALL, FLOOR, SEAM = 3.0, 3.0, 30.0
WINDOW_BOTTOM, WINDOW_TOP = 8.0, 55.0
INSERT_BORE, INSERT_DEPTH = 4.2, 6.0
SCREW_CLEARANCE = 3.4
CORNERS = [(6, 6), (W-6, 6), (6, D-6), (W-6, D-6)]
PINS = [(x + (3 if x < W/2 else -3),
         y + (3 if y < D/2 else -3)) for x, y in CORNERS]
RAIL_Y = [28.0, 132.0]  # Preview only; continuously adjustable, 21..139.


def box(x, y, z, dx, dy, dz):
    return cq.Workplane("XY").box(dx, dy, dz, centered=False).translate((x, y, z))


def cyl(x, y, z, diameter, height):
    return cq.Workplane("XY").circle(diameter/2).extrude(height).translate((x, y, z))


def rounded_box(x, y, z, dx, dy, dz, radius):
    return box(x, y, z, dx, dy, dz).edges("|Z").fillet(radius)


def slot(x, y, z, length, width, depth, angle=0):
    return (cq.Workplane("XY").slot2D(length, width, angle).extrude(depth)
            .translate((x, y, z)))


def windows():
    # Continuous access on EVERY board edge avoids guessed connector locations.
    return [box(12, -1, WINDOW_BOTTOM, W-24, WALL+2, WINDOW_TOP-WINDOW_BOTTOM),
            box(12, D-WALL-1, WINDOW_BOTTOM, W-24, WALL+2, WINDOW_TOP-WINDOW_BOTTOM),
            box(-1, 12, WINDOW_BOTTOM, WALL+2, D-24, WINDOW_TOP-WINDOW_BOTTOM),
            box(W-WALL-1, 12, WINDOW_BOTTOM, WALL+2, D-24, WINDOW_TOP-WINDOW_BOTTOM)]


def vent_cutters(z, depth, bottom=False):
    # Short slots retain cross-ribs and print flat on the bed.
    ys = range(49, 116, 6) if bottom else range(25, 140, 6)
    xs = [48, 84, 120] if bottom else [30, 66, 102, 138]
    return [slot(x, y, z, 29, 3, depth) for x in xs for y in ys]


def cut_many(part, cutters):
    return part.cut(cq.Compound.makeCompound([c.val() for c in cutters]))


def make_shells():
    base = rounded_box(0, 0, 0, W, D, SEAM, 6)
    base = base.cut(rounded_box(WALL, WALL, FLOOR, W-2*WALL, D-2*WALL,
                                SEAM, 3))
    lid = rounded_box(0, 0, SEAM, W, D, H-SEAM, 6)
    lid = lid.cut(rounded_box(WALL, WALL, SEAM-1, W-2*WALL, D-2*WALL,
                              H-FLOOR-SEAM+1, 3))
    for x, y in CORNERS:
        base = base.union(cyl(x, y, FLOOR, 12, SEAM-FLOOR))
        lid = lid.union(cyl(x, y, SEAM, 12, H-SEAM))
    base = cut_many(base, windows() + vent_cutters(-1, FLOOR+2, bottom=True))
    lid = cut_many(lid, windows() + vent_cutters(H-FLOOR-1, FLOOR+2))
    for x, y in CORNERS:
        base = base.cut(cyl(x, y, SEAM-INSERT_DEPTH, INSERT_BORE, INSERT_DEPTH+1))
        lid = lid.cut(cyl(x, y, SEAM-1, SCREW_CLEARANCE, H-SEAM+2))
        # M3x10 screw seats on 4 mm of plastic; long screwdriver access well.
        lid = lid.cut(cyl(x, y, SEAM+4, 6.6, H-SEAM))
    for x, y in PINS:
        pin = cyl(x, y, SEAM-0.1, 2.8, 2.7).edges(">Z").chamfer(0.35)
        base = base.union(pin)
        lid = lid.cut(cyl(x, y, SEAM-0.1, 3.4, 3.2))
    # Sliding rail anchors: centre travel is y=21..139 (118 mm).
    for x in (8, W-8):
        base = base.cut(slot(x, D/2, -1, 121.4, 3.4, FLOOR+2, 90))
    return base, lid


def make_rail():
    # Anchor holes lie outside the 140 mm PCB envelope.
    rail = rounded_box(3, -5, 8, W-6, 10, 4, 2)
    rail = rail.cut(slot(W/2, 0, 7, 139.4, 3.4, 6))
    for x in (8, W-8):
        rail = rail.cut(cyl(x, 0, 7, 3.4, 6))
    return rail


def make_spacer():
    return cyl(0, 0, 0, 8, 5).cut(cyl(0, 0, -1, 3.4, 7))


def make_coupon():
    # The blind insert hole and small through hole use the actual CAD sizes.
    c = rounded_box(0, 0, 0, 30, 18, 8, 2)
    return c.cut(cyl(8, 9, 2, INSERT_BORE, 7)).cut(cyl(22, 9, -1, 3.4, 10))


def validate(base, lid, rail, spacer, coupon):
    report = {"status": "CAD geometry checked; physical board fit NOT verified",
              "outside_mm": [W, D, H], "board_underside_z_mm": 20,
              "inside_roof_z_mm": H-FLOOR,
              "mounting_x_centres_mm": [16, 152],
              "mounting_y_centres_mm": [21, 139],
              "source_envelope_mm": [140, 132, 36],
              "parts": {}}
    for name, part in [("base", base), ("lid", lid), ("rail", rail),
                       ("spacer", spacer), ("fit_coupon", coupon)]:
        assert part.val().isValid(), f"Invalid BREP: {name}"
        assert len(part.solids().vals()) == 1, f"Disconnected part: {name}"
        report["parts"][name] = {"valid_brep": True, "solids": 1,
                                 "volume_mm3": round(part.val().Volume(), 2)}
    overlap = base.intersect(lid).val().Volume()
    assert overlap < 1e-6, f"Clamshell collision: {overlap}"
    report["shell_overlap_mm3"] = round(overlap, 8)
    for yy in (21, 28, 80, 132, 139):
        r = rail.translate((0, yy, 0))
        assert r.intersect(base).val().Volume() < 1e-6
        assert r.intersect(lid).val().Volume() < 1e-6
    # Conservative rectangular kit envelope only, NOT a detailed board model.
    envelope = box(14, 14, 20, 140, 132, 36)
    for name, part in [("base", base), ("lid", lid)]:
        volume = part.intersect(envelope).val().Volume()
        assert volume < 1e-6, f"Envelope collision: {name}"
    report["rectangular_envelope_collision_mm3"] = 0
    # Unobstructed paths through each full perimeter aperture.
    for opening in windows():
        for part in (base, lid):
            assert part.intersect(opening).val().Volume() < 1e-6
    report["all_four_access_windows_clear"] = True
    return report


def preview(base, lid, rail):
    # Depth-buffered CAD rendering avoids painter-order artifacts through vents.
    import vtk
    window = vtk.vtkRenderWindow()
    window.SetOffScreenRendering(1)
    window.SetSize(2048, 1170)
    window.SetMultiSamples(4)
    for index, exploded in enumerate((False, True)):
        renderer = vtk.vtkRenderer()
        renderer.SetViewport(index/2, 0, (index+1)/2, 1)
        renderer.SetBackground(0.95, 0.96, 0.97)
        window.AddRenderer(renderer)
        items = [(base, (0.24, 0.34, 0.41)),
                 (lid.translate((0, 0, 46 if exploded else 0)), (0.74, 0.82, 0.87))]
        if exploded:
            items += [(rail.translate((0, yy, 0)), (0.89, 0.67, 0.34)) for yy in RAIL_Y]
        for part, color in items:
            vertices, triangles = part.val().tessellate(0.2)
            points = vtk.vtkPoints()
            for v in vertices:
                points.InsertNextPoint(*v.toTuple())
            cells = vtk.vtkCellArray()
            for triangle in triangles:
                cells.InsertNextCell(3, triangle)
            data = vtk.vtkPolyData()
            data.SetPoints(points)
            data.SetPolys(cells)
            normals = vtk.vtkPolyDataNormals()
            normals.SetInputData(data)
            normals.SetFeatureAngle(35)
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInputConnection(normals.GetOutputPort())
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            actor.GetProperty().SetColor(*color)
            actor.GetProperty().SetAmbient(0.25)
            actor.GetProperty().SetDiffuse(0.75)
            renderer.AddActor(actor)
        camera = renderer.GetActiveCamera()
        camera.SetPosition(330, -330, 330)
        camera.SetFocalPoint(W/2, D/2, 58)
        camera.SetViewUp(0, 0, 1)
        camera.ParallelProjectionOn()
        camera.SetParallelScale(165)
        renderer.ResetCameraClippingRange()
        def label(text, y, size):
            actor = vtk.vtkTextActor()
            actor.SetInput(text)
            actor.GetTextProperty().SetFontSize(size)
            actor.GetTextProperty().SetColor(0.14, 0.21, 0.28)
            actor.GetTextProperty().SetJustificationToCentered()
            actor.GetPositionCoordinate().SetCoordinateSystemToNormalizedViewport()
            actor.GetPositionCoordinate().SetValue(0.5, y)
            renderer.AddViewProp(actor)
        label("KR260 / SCREW-FASTENED CLAMSHELL", 0.92, 28)
        label("EXPLODED / SLIDING RAILS" if exploded else "ASSEMBLED", 0.84, 23)
        label("168 x 160 x 68 mm | Four M3 closure screws", 0.12, 22)
        label("PROTOTYPE - physical fit check required", 0.07, 20)
    window.Render()
    capture = vtk.vtkWindowToImageFilter()
    capture.SetInput(window)
    capture.Update()
    writer = vtk.vtkPNGWriter()
    writer.SetFileName(str(OUT / "preview.png"))
    writer.SetInputConnection(capture.GetOutputPort())
    writer.Write()
    window.Finalize()


def main():
    OUT.mkdir(exist_ok=True)
    base, lid = make_shells()
    rail, spacer, coupon = make_rail(), make_spacer(), make_coupon()
    report = validate(base, lid, rail, spacer, coupon)
    parts = {"base": base,
             "lid": lid.rotate((0, 0, 0), (1, 0, 0), 180).translate((0, D, H)),
             "mounting_rail": rail.translate((0, 5, -8)),
             "rail_spacer": spacer, "fit_coupon": coupon}
    for name, part in parts.items():
        path = OUT / f"{name}.stl"
        cq.exporters.export(part, str(path), tolerance=0.05, angularTolerance=0.1)
        mesh = trimesh.load_mesh(path)
        assert mesh.is_watertight and mesh.is_winding_consistent and mesh.volume > 0, name
        assert len(mesh.split()) == 1, name
        assert abs(mesh.bounds[0, 2]) < 1e-5, f"Not on bed: {name}"
        report.setdefault("stl_checks", {})[name] = {
            "watertight": True, "connected_components": 1,
            "consistent_winding": True, "on_print_bed": True,
            "triangles": len(mesh.faces)}
    asm = cq.Assembly(name="KR260_clamshell_prototype")
    asm.add(base, name="base", color=cq.Color(0.24, 0.34, 0.41))
    asm.add(lid, name="lid", color=cq.Color(0.74, 0.82, 0.87))
    for i, yy in enumerate(RAIL_Y):
        asm.add(rail.translate((0, yy, 0)), name=f"rail_{i+1}")
        for j, xx in enumerate((8, W-8)):
            asm.add(spacer.translate((xx, yy, FLOOR)), name=f"spacer_{i+1}_{j+1}")
    cq.exporters.export(asm.toCompound(), str(OUT / "clamshell.step"))
    (OUT / "validation.json").write_text(json.dumps(report, indent=2) + "\n")
    preview(base, lid, rail)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
