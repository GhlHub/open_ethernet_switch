# KR260 screw-fastened clamshell

A printable **prototype** for the KR260 with its stock cooling assembly. Two
shells close with four M3 machine screws into brass inserts. Large continuous
openings on all four edges leave space for network, power, USB and microSD
access without relying on unverified connector coordinates. This is an open-I/O
desktop enclosure, not a sealed enclosure.

![Assembled and exploded CAD views](output/preview.png)

## Files

| File | Purpose / quantity |
| --- | --- |
| [base.stl](output/base.stl) | Lower shell; print 1 |
| [lid.stl](output/lid.stl) | Upper shell; print 1, already turned roof-down |
| [mounting_rail.stl](output/mounting_rail.stl) | Sliding PCB mounting rail; print 2 |
| [rail_spacer.stl](output/rail_spacer.stl) | Rail-to-floor spacer; print 4 |
| [fit_coupon.stl](output/fit_coupon.stl) | Small screw/insert sizing sample; print first |
| [clamshell.step](output/clamshell.step) | Both shells, two rails and four spacers in assembly coordinates |
| [preview.png](output/preview.png) | Actual generated geometry, assembled and exploded |
| [validation.json](output/validation.json) | CAD and mesh verification results |
| [build.py](build.py) | Editable parametric CadQuery source; millimetres |

The STEP file does not contain a KR260 board model or purchased hardware.

## Dimensions and access

* Outside: **168 × 160 × 68 mm**, excluding adhesive feet.
* Shells: 3 mm walls/floor/roof, rounded corners, seam 30 mm above the base.
* Front/back openings: 144 mm wide × 47 mm tall.
* Left/right openings: 136 mm wide × 47 mm tall.
* All openings extend from z=8 to z=55 mm and cross the shell seam.
* Board underside: nominal z=20 mm, using 8 mm PCB standoffs.
* Inside roof: z=65 mm; 9 mm above the top of the conservative 36 mm kit envelope.
* Roof: 80 ventilation slots; base: 36 ventilation slots. Keep the stock fan fitted.
* Four corner locating pins align the shells; four recessed M3 screws retain them.

Use whichever face corresponds to your board orientation. The broad openings
serve the four RJ45s, SFP cage, barrel jack, four USB-A ports, micro-USB debug
connector and microSD, including the space below the PCB. DisplayPort and
edge expansion connections are also exposed. The opening does not add a narrow
SD tunnel: a finger can approach the card through the open lower edge region.
Bulky plug mouldings, RJ45 latch operation and SFP release travel still need a
physical check with your cables.

## Board mounting without a measured hole pattern

Two rails slide along the base's two longitudinal slots. Each rail has a long
cross-slot for two separate PCB standoffs. Position the rails and standoffs
against the actual board's mounting holes, then tighten them. Do not clamp the
board edge, mount on components, or use the SOM attachment screws.

Relative to the base's outside lower-left corner:

| Adjustment | Usable screw-centre range |
| --- | --- |
| PCB mounting standoffs across each rail | x=16..152 mm |
| Each rail along the base | y=21..139 mm |
| Rail anchor screws | x=8 and x=160 mm |

This accommodates a four-hole pattern in two rows within those ranges. The
preview places the rails at y=28 and y=132 purely to illustrate the mechanism;
these are **not claimed KR260 mounting-hole coordinates**. Centre the kit within
the case, allowing for connectors that overhang the PCB. Verify at least 8 mm
clearance between the PCB underside and rail top, including solder tails and
microSD hardware. Rail positions must not cause a component collision.

## Hardware

| Quantity | Item |
| --- | --- |
| 4 | M3 × 10 mm socket-head screws for the shells |
| 4 | M3 brass heat-set inserts, nominal 4.5–4.6 mm outside diameter × 5 mm long |
| 4 | M3 × 16 mm screws for the rail anchors |
| 4 | M3 hex nuts for the rail anchors |
| 8 | M3 flat washers, one above each rail anchor and one below the floor |
| 4 | M3 female/female nylon standoffs, 8 mm long; maximum outside diameter 6 mm |
| 4 | M3 × 8 mm screws to secure the PCB standoffs from below each rail |
| 4 | M3 × 6 mm screws and insulating washers for the PCB |
| 4 | Adhesive rubber feet, at least 5 mm tall, to clear nuts below the base |

Check that M3 screws pass freely through the carrier mounting holes before
assembly. If your board requires smaller screws, substitute matching PCB
hardware and washers; the rail slots are 3.4 mm wide. Verify screw engagement
in the actual standoffs and avoid bottoming screws in blind threads.

The insert bores are 4.2 mm diameter and 6 mm deep. Insert manufacturers specify
different pilot-hole sizes: use the coupon and change `INSERT_BORE` if needed.
The coupon's hole at x=8 is the insert bore; x=22 is the 3.4 mm clearance hole.
Do not force inserts into an undersized print.

## Print and assemble

1. Print the fit coupon, two rails and four spacers first. Check your inserts,
   screws and the rails' reach against the actual carrier board.
2. Print the base and lid in the supplied STL orientations. Both have their
   exterior flat face on the bed; the lid is rotated, not mirrored. The open
   windows terminate at the seam, avoiding long unsupported bridges.
3. Suggested starting settings: PETG, 0.2 mm layers, 0.4 mm nozzle, 4 perimeters,
   5 top/bottom layers, 30% infill. Use solid infill for rails and spacers. Inspect
   the slicer preview; the long rail anchor slots rely on adhesion at their ends.
4. Heat-set the four inserts into the base corner posts with the board removed.
   Seat each insert flush at the seam. Let them cool.
5. Screw the four nylon standoffs to the rails from below, initially loose. Fit
   the board to the standoffs with insulating washers, without powering it.
6. Put a printed 5 mm spacer under each rail anchor. Feed the M3 × 16 screws
   down through a washer, rail, spacer and base slot, then fit a washer and nut
   underneath. Adjust rail and standoff positions; tighten gently. To tighten
   screws below the rails, lift the board/rail assembly out as necessary.
7. Confirm the PCB is supported only at its mounting holes and that the rails
   clear all underside components. Add the four adhesive feet near the corners.
8. Check all plugs and microSD insertion/removal, then fit the lid on the pins.
   Drop four M3 × 10 screws down the corner wells and tighten into the inserts.
   A straight 2.5 mm hex driver with at least 35 mm reach suits typical socket heads.
9. Run the intended workload and check cooling with the lid fitted. Airflow and
   operating temperatures have not been physically tested.

## Reference and confidence

AMD's [DS988 mechanical specification](https://docs.amd.com/r/en-US/ds988-kr260-starter-kit/Mechanical)
lists a 132 × 140 × 36 mm assembled starter-kit envelope. Its mechanical figures
also distinguish a 119 mm dimension; this design conservatively reserves the
larger envelope including protruding connectors. AMD's
[KR260 product specification](https://www.amd.com/en/products/system-on-modules/kria/k26/kr260-robotics-starter-kit.html)
identifies the interfaces and active cooling. References checked 2026-09-27.

The referenced AMD carrier CAD archive is
`xtp744-kr260-carrier-card-3d-cad-model.zip`. Its download could not be obtained
during design, so **no exact hole pattern, PCB outline, connector positions or
component keep-outs have been verified against vendor CAD**. This is why the
design uses adjustable rails and broad edge openings. Physical fit is not
guaranteed: print the small parts first and check the actual board before
committing to the shells. Do not treat the simple envelope collision check as
a detailed board fit check.

## Regenerate and verify

```sh
python3 -m venv /tmp/kr260-cad
/tmp/kr260-cad/bin/pip install -r mechanical/kr260-enclosure/requirements.txt
/tmp/kr260-cad/bin/python mechanical/kr260-enclosure/build.py
```

Generation verifies valid single-solid BREP parts, no shell-to-shell collision,
rail travel clear of the shells at representative positions, a clear conservative
rectangular board envelope, and four unobstructed window volumes. Each exported
STL is checked for watertightness, consistent winding, a single connected mesh,
positive volume and placement on the print bed. These checks do not validate
printer tolerances, material strength, cable fit or thermal performance.
